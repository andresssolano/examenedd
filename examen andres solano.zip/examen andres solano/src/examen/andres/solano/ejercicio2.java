/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.andres.solano;
/**
 *
 * @author Okhapi
 */
public class ejercicio2 {
}
   class nodo {
    String palabra;
    nodo siguiente;
    public nodo(String palabra) {
        this.palabra = palabra;
        this.siguiente = null;
    }
}
class listacircular{
    nodo cabeza;
    public listacircular() {
        cabeza = null;
    }
    public void encolar(String palabra) {
        nodo nuevonodo=new nodo(palabra);
        if (cabeza==null) {
            cabeza=nuevonodo;
            cabeza.siguiente =cabeza; 
        } else {
            nodo temp=cabeza;
            while (temp.siguiente !=cabeza) {
                temp=temp.siguiente;
            }
            temp.siguiente=nuevonodo;
            nuevonodo.siguiente=cabeza;
        }
    }
    public String concatenar() {
        if (cabeza==null) {
            return "";
        }
        StringBuilder resultado=new StringBuilder();
        nodo actual=cabeza;
        do {
            resultado.append(actual.palabra).append(" ");
            actual=actual.siguiente;
        } while (actual!=cabeza);
        if (resultado.length()>0) {
            resultado.setLength(resultado.length()-1);
        }
        return resultado.toString();
    }
    public static void main(String[] args){
        listacircular lista=new listacircular();
        lista.encolar("saquenme");
        lista.encolar("de");
        lista.encolar("ingenieria");
        lista.encolar("por");
        lista.encolar("favor");
        lista.encolar("me");
        lista.encolar("estan");
        lista.encolar("matando");
        String resultado=lista.concatenar();
        System.out.println(resultado); 
    }
}
    
