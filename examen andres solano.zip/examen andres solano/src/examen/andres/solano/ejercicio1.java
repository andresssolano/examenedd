/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package examen.andres.solano;

import java.util.Scanner;

public class ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        Scanner scanner =new Scanner(System.in);
        System.out.print("ingrese el tamaño del arreglo");
        int o =scanner.nextInt();
        int[] arreglo =new int[o];
        llenar(arreglo,0,scanner);
        int resultado = suma(arreglo, arreglo.length-1);
        System.out.println("La suma es "+resultado);
    }
    public static int suma(int[]arreglo,int n){
        if (n<0){
            return 0;
        }
        else return arreglo[n]+suma(arreglo,n-1);
    }
     public static void llenar(int[]arreglo, int i,Scanner scanner){
        if (i<arreglo.length){
            System.out.print("Ingrese el elemento "+(i+1));
            arreglo[i]=scanner.nextInt();
            llenar(arreglo,i+1,scanner);
                    }
            }
}