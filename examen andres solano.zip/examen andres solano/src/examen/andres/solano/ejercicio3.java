/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.andres.solano;

/**
 *
 * @author Okhapi
 */
public class ejercicio3<T> {
    private Nodo<T> cima;
    private static class Nodo<T> {
        T dato;
        Nodo<T> siguiente;
        Nodo(T dato, Nodo<T> siguiente) {
            this.dato = dato;
            this.siguiente = siguiente;
        }
    }
    public void apilar(T dato) {
        cima = new Nodo<>(dato, cima);
    }
    public T desapilar() {
        if (esVacia()) {
            throw new IllegalStateException();
        }
        T dato = cima.dato;
        cima = cima.siguiente;
        return dato;
    }
    public boolean esVacia() {
        return cima == null;
    }
    public void imprimirInvertido() {
        imprimirInvertidoRecursivo(this);
    }
    private void imprimirInvertidoRecursivo(ejercicio3<T> pila) {
        if (pila.esVacia()) {
            return;
        }
        T dato = pila.desapilar();
        imprimirInvertidoRecursivo(pila); 
        System.out.println(dato); 
        pila.apilar(dato); 
    }
    public static void main(String[] args) {
        ejercicio3<Integer> pila = new ejercicio3<>();
        pila.apilar(5);
        pila.apilar(4);
        pila.apilar(3);
        pila.apilar(2);
        pila.apilar(1);
        pila.imprimirInvertido();
    }
}
