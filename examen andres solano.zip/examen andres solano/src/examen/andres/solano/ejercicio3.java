/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.andres.solano;

/**
 *
 * @author Okhapi
 */
public class ejercicio3 {
class Nodo {
    int valor;
    Nodo siguiente;

    Nodo(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}
public class Pila {
    private Nodo cima;

    public Pila() {
        this.cima = null;
    }
    public void push(int valor) {
        Nodo nuevoNodo = new Nodo(valor);
        nuevoNodo.siguiente = cima;
        cima = nuevoNodo;
    }
    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("La pila está vacía");
        }
        int valor = cima.valor;
        cima = cima.siguiente;
        return valor;
    }
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("La pila está vacía");
        }
        return cima.valor;
    }
    public boolean isEmpty() {
        return cima == null;
    }
public class Main {
    public static void main(String[] args) {
        Pila pila = new Pila();
        pila.push(1);
        pila.push(2);
        pila.push(3);
        pila.push(4);

        System.out.println("Valores invertidos de la pila:");
        imprimirInvertido(pila);
    }

    public static void imprimirInvertido(Pila pila) {
        // Caso base: Si la pila está vacía, terminamos
        if (pila.isEmpty()) {
            return;
        }

        // Paso recursivo: Retiramos el elemento superior de la pila
        int valor = pila.pop();

        // Llamada recursiva para procesar los demás elementos
        imprimirInvertido(pila);

        // Imprimir el valor del elemento retirado después de la llamada recursiva
        System.out.println(valor);
        
        // Volver a insertar el valor en la pila para restaurar el estado original
        pila.push(valor);
    }
}
}
}