/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.andres.solano;

import java.util.Scanner;

/**
 *
 * @author Okhapi
 */
public class ejercicio4 {
     public static long factorial(int numero) {
        if(numero<=1){
            return 1;
        }
        return numero*factorial(numero-1);
    }
    public static double potencia(double base,int exponente) {
        if (exponente==0){
            return 1;
        }
        return base*potencia(base,exponente-1); 
    }
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.print("Ingrese su factorial: ");
        int numeroFactorial = scanner.nextInt();
        System.out.print("Ingrese la base de la potencia: ");
        double base=scanner.nextDouble();
        System.out.print("Ingrese el exponente de la potencia: ");
        int exponente=scanner.nextInt();
        long A=factorial(numeroFactorial);
        double B=potencia(base,exponente);
        double resultado=A*B;
        System.out.println("El resultado es "+resultado);
        scanner.close();
    }
}
